import struct

from spy.libspy import LLSPyInstance, SPyError
from spy.llwasm import LLWasmModule
from spy.tests.support import CTest


def mk_spy_Str(utf8: bytes) -> bytes:
    """
    Return the spy_Str representation of the given utf8 bytes.

    For example, for b'hello' we have the following in-memory repr:
         <i   4 bytes of length, little endian
         i    4 bytes of hash (0 for uncached)
         5s   5 bytes of data (b'hello')
    """
    n = len(utf8)
    fmt = f"<ii{n}s"
    return struct.pack(fmt, n, 0, utf8)


class TestLibSPy(CTest):
    def test_walloc(self):
        src = r"""
        #include <spy.h>

        char *
        WASM_EXPORT(make_str)(char a, char b, char c) {
            char *buf = malloc(4);
            buf[0] = a;
            buf[1] = b;
            buf[2] = c;
            buf[3] = '\0';
            return buf;
        }
        """
        test_wasm = self.c_compile(src)
        ll = LLSPyInstance.from_file(test_wasm)
        p1 = ll.call("make_str", ord("A"), ord("B"), ord("C"))
        p2 = ll.call("make_str", ord("X"), ord("Y"), ord("Z"))
        assert p1 != p2
        abc = ll.mem.read(p1, 4)
        assert abc == b"ABC\0"
        xyz = ll.mem.read(p2, 4)
        assert xyz == b"XYZ\0"

    def test_str(self):
        src = r"""
        #include <spy.h>

        spy_Str H = {6, 0, "hello "};

        spy_Str *mk_W(void) {
            spy_Str *s = spy_str_alloc(5);
            memcpy((void*)s->utf8, "world", 5);
            return s;
        }
        """
        test_wasm = self.c_compile(src, exports=["H", "mk_W"])
        ll = LLSPyInstance.from_file(test_wasm)
        ptr_H = ll.read_global("H")
        assert ll.mem.read(ptr_H, 14) == mk_spy_Str(b"hello ")
        #
        ptr_W = ll.call("mk_W")
        assert ll.mem.read(ptr_W, 13) == mk_spy_Str(b"world")
        #
        ptr_HW = ll.call("spy_str_add", ptr_H, ptr_W)
        assert ll.mem.read(ptr_HW, 19) == mk_spy_Str(b"hello world")

    def test_debug_log(self):
        src = r"""
        #include <spy.h>

        void log_hello(void) {
            spy_debug_log("hello");
            spy_debug_log("world");
        }
        """
        test_wasm = self.c_compile(src, exports=["log_hello"])
        llmod = LLWasmModule(str(test_wasm))
        ll = LLSPyInstance(llmod)
        ll.call("log_hello")
        assert ll.libspy.log == ["hello", "world"]

    def test_panic(self):
        src = r"""
        #include <spy.h>

        void crash(void) {
            spy_panic("PanicError", "don't panic!", "myfile", 42);
        }
        """
        test_wasm = self.c_compile(src, exports=["crash"])
        ll = LLSPyInstance.from_file(test_wasm)
        with SPyError.raises("W_PanicError", match="don't panic!") as excinfo:
            ll.call("crash")
        loc = excinfo.value.w_exc.annotations[0].loc
        assert loc.filename == "myfile"
        assert loc.line_start == 42
