from typing import TYPE_CHECKING

from spy.vm.function import W_Func
from spy.vm.opspec import W_MetaArg
from spy.vm.primitive import W_Dynamic
from spy.vm.str import W_Str

from . import OP

if TYPE_CHECKING:
    from spy.vm.vm import SPyVM


def _dynamic_op(
    vm: "SPyVM",
    w_op: W_Func,
    w_a: W_Dynamic,
    w_b: W_Dynamic,
) -> W_Dynamic:
    wam_a = W_MetaArg.from_w_obj(vm, w_a)
    wam_b = W_MetaArg.from_w_obj(vm, w_b)
    w_opimpl = vm.call_OP(None, w_op, [wam_a, wam_b])
    # XXX this is wrong: we probably need a big rethink of how we deal with dynamic
    return w_opimpl._execute(vm, [w_a, w_b])


@OP.builtin_func
def w_dynamic_add(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_ADD, w_a, w_b)


@OP.builtin_func
def w_dynamic_sub(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_SUB, w_a, w_b)


@OP.builtin_func
def w_dynamic_mul(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_MUL, w_a, w_b)


@OP.builtin_func
def w_dynamic_mod(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_MOD, w_a, w_b)


@OP.builtin_func
def w_dynamic_div(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_DIV, w_a, w_b)


@OP.builtin_func
def w_dynamic_floordiv(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_FLOORDIV, w_a, w_b)


@OP.builtin_func
def w_dynamic_lshift(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_LSHIFT, w_a, w_b)


@OP.builtin_func
def w_dynamic_rshift(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_RSHIFT, w_a, w_b)


@OP.builtin_func
def w_dynamic_and(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_AND, w_a, w_b)


@OP.builtin_func
def w_dynamic_or(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_OR, w_a, w_b)


@OP.builtin_func
def w_dynamic_xor(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_XOR, w_a, w_b)


@OP.builtin_func
def w_dynamic_eq(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    # NOTE: == between dynamic uses UNIVERSAL_EQ
    return _dynamic_op(vm, OP.w_UNIVERSAL_EQ, w_a, w_b)


@OP.builtin_func
def w_dynamic_ne(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_UNIVERSAL_NE, w_a, w_b)


@OP.builtin_func
def w_dynamic_lt(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_LT, w_a, w_b)


@OP.builtin_func
def w_dynamic_le(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_LE, w_a, w_b)


@OP.builtin_func
def w_dynamic_gt(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_GT, w_a, w_b)


@OP.builtin_func
def w_dynamic_ge(vm: "SPyVM", w_a: W_Dynamic, w_b: W_Dynamic) -> W_Dynamic:
    return _dynamic_op(vm, OP.w_GE, w_a, w_b)


@OP.builtin_func
def w_dynamic_setattr(
    vm: "SPyVM", w_obj: W_Dynamic, w_name: W_Str, w_value: W_Dynamic
) -> W_Dynamic:
    wam_obj = W_MetaArg.from_w_obj(vm, w_obj)
    wam_name = W_MetaArg.from_w_obj(vm, w_name)
    wam_v = W_MetaArg.from_w_obj(vm, w_value)
    w_opimpl = vm.call_OP(None, OP.w_SETATTR, [wam_obj, wam_name, wam_v])
    return w_opimpl._execute(vm, [w_obj, w_name, w_value])  # XXX


@OP.builtin_func
def w_dynamic_getattr(vm: "SPyVM", w_obj: W_Dynamic, w_name: W_Str) -> W_Dynamic:
    wam_obj = W_MetaArg.from_w_obj(vm, w_obj)
    wam_name = W_MetaArg.from_w_obj(vm, w_name)
    w_opimpl = vm.call_OP(None, OP.w_GETATTR, [wam_obj, wam_name])
    return w_opimpl._execute(vm, [w_obj, w_name])  # XXX


@OP.builtin_func
def w_dynamic_call(vm: "SPyVM", w_obj: W_Dynamic, *args_w: W_Dynamic) -> W_Dynamic:
    all_args_w = [w_obj] + list(args_w)
    all_args_wam = [W_MetaArg.from_w_obj(vm, w_x) for i, w_x in enumerate(all_args_w)]
    w_opimpl = vm.call_OP(None, OP.w_CALL, all_args_wam)
    return w_opimpl._execute(vm, all_args_w)  # XXX
